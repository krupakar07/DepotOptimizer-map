import html
from pathlib import Path

import streamlit as st
import streamlit.components.v1 as components

st.set_page_config(
    page_title="Mannheim Depot Optimizer",
    page_icon="🚚",
    layout="wide",
    initial_sidebar_state="expanded",
)

ROOT = Path(__file__).resolve().parent
FRONTEND_HTML = ROOT / "frontend" / "index.html"

st.markdown(
    """
    <style>
    [data-testid="stSidebar"] { min-width: 250px; max-width: 250px; }
    .block-container { padding-top: 0.8rem; padding-bottom: 0.8rem; }
    div[data-testid="stVerticalBlock"] > div:has(> iframe) { padding: 0 !important; }
    .streamlit-map-frame iframe { border: 0 !important; }
    </style>
    """,
    unsafe_allow_html=True,
)

st.sidebar.title("🚚 Mannheim Depot")
st.sidebar.caption("Planning workspace")
page = st.sidebar.radio(
    "Navigation",
    ["🗺️ Live Map & Driver Planning", "🧠 Python Optimizer (OR-Tools)"],
    label_visibility="collapsed",
)

st.sidebar.divider()
st.sidebar.caption("GitHub is the source of truth. Streamlit Community Cloud runs this app.")

if page.startswith("🗺️"):
    if not FRONTEND_HTML.exists():
        st.error("Frontend map file is missing: frontend/index.html")
        st.stop()

    # The map is intentionally kept inside a browser-side component.
    # ZIP clicks, driver selection, labels, popups and Excel parsing therefore
    # happen in JavaScript without causing a Streamlit/Python rerun on every click.
    source = FRONTEND_HTML.read_text(encoding="utf-8")
    components.html(
        source,
        height=920,
        scrolling=False,
    )
else:
    # Keep the original Python/OR-Tools optimizer available as a first-class
    # Streamlit page. This is the exact Python optimization engine, not the
    # browser heuristic contained in the map UI.
    from optimizer_page import render_optimizer
    render_optimizer()
